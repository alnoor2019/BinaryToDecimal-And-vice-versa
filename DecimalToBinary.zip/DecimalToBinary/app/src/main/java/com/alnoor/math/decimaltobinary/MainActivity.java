package com.alnoor.math.decimaltobinary;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2;
    TextView tv1,tv2,res;
    RadioGroup rg;
    RadioButton DtoB,BtoD;
    String text1,text2,ntv1,ntv2,resultBinary,resultDecimal,et1,et2;
    long result;
    char[] chofInput;
    int[] intgerOfInput;
    int decNum;
    boolean isBinary;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        try {
        initallze();
        ed2.setEnabled(false);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(BtoD.isChecked()){
                    ed1.setText("");
                    ed2.setText("");
                    tv1.setText(R.string.tb);
                    tv2.setText(R.string.td);
                }
                else if(DtoB.isChecked()){
                    ed1.setText("");
                    ed2.setText("");
                    tv1.setText(R.string.td);
                    tv2.setText(R.string.tb);
                }
            }
        });}catch(Exception e)

    {

    }


        try{
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                et1 = ed1.getText().toString();
                et2 = ed2.getText().toString();
                text1 = tv1.getText().toString();
                text2 = tv2.getText().toString();
                ntv1 = getResources().getString(R.string.tb);
                ntv2 = getResources().getString(R.string.td);
                if(!DtoB.isChecked()&&!BtoD.isChecked()){
                    Toast.makeText(MainActivity.this,getResources().getString(R.string.toast),Toast.LENGTH_SHORT).show();
                }

                else{
                    if(text1==ntv1&&text2==ntv2){
                        try {
                            operationDecmial();
                        }catch (Exception e){
                            ed2.setText("");
                            Toast.makeText(MainActivity.this,getResources().getString(R.string.toError),Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        try {
                            operataionBinary();
                        }catch (Exception e){
                            ed2.setText("");
                            Toast.makeText(MainActivity.this,getResources().getString(R.string.toError),Toast.LENGTH_SHORT).show();
                        }

                    }
                }

            }
        });}catch(Exception e){
            Toast.makeText(MainActivity.this,getResources().getString(R.string.toError),Toast.LENGTH_SHORT).show();
        }
    }

    public void operationDecmial() {
        chofInput = Convert.breakString(et1);
        intgerOfInput = Convert.charToInt(chofInput);

        boolean test = Convert.isBinary(intgerOfInput);
        if(test==true){

            decNum = Integer.parseInt(et1,2);
            ed2.setText(String.valueOf(decNum));

        }else{
            Toast.makeText(MainActivity.this,getResources().getString(R.string.toNotBinary),Toast.LENGTH_SHORT).show();
            ed2.setText("");
        }
    }

    public void operataionBinary() {

        Convert.BinaryResult="";
        result = Long.parseLong(et1);
        Convert.DecimalToBinary(result);
        resultBinary = Convert.BinaryResult.toString();
        ed2.setText(Convert.ruotae(resultBinary));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(MainActivity.this,About.class);
            startActivity(i);
        }

        return true;
    }

    private void initallze(){
        ed1 = (EditText)findViewById(R.id.edit1);
        ed2 = (EditText)findViewById(R.id.edit2);
        tv1 = (TextView)findViewById(R.id.text1);
        tv2 = (TextView)findViewById(R.id.text2);
        rg = (RadioGroup)findViewById(R.id.group);
        DtoB = (RadioButton)findViewById(R.id.DtoB);
        BtoD = (RadioButton)findViewById(R.id.BtoD);

    }

}
