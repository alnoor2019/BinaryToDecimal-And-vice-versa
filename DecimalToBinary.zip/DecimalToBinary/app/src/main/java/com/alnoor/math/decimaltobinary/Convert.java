package com.alnoor.math.decimaltobinary;

/**
 * Created by alnoor majzoob on 12/23/2018.
 */

public class Convert {

    public static String BinaryResult="";

    /**
     * this method uset to convert decimal number to binary
     * @param x is integer
     * @return the result(binary)
     */
    public static void DecimalToBinary(long x) {


        long r = x % 2;

        if (r == 0) {
            long res = x / 2;
            BinaryResult = BinaryResult + "0";
            if (res == 0) {
                ruotae(BinaryResult);
            } else {
                DecimalToBinary(res);
            }

        } else {
            long v = x / 2;
            BinaryResult = BinaryResult + "1";
            if (v == 0) {
                ruotae(BinaryResult);
            } else {
                DecimalToBinary(v);
            }
        }


    }

    /**
     * this method use to convert binary number to decimal
     * @param x is integer
     * @return the result decimal
     */
    public static long BinaryToDecimal(long x){
        long decimal=0,p=0;

        while(x!=0)
        {
            decimal+=((x%10)*Math.pow(2,p));
            x=x/10;
            p++;
        }
        return decimal;
    }

    /**
     * this method use to check if input is a binary number
     * @param x is integer array
     * @return true if the input is binary or false if input is not binary
     */
    public static boolean isBinary(int[] x){
        boolean isBinary = false;
        String countFalse="";
        for(int i=0;i<x.length;i++)
        {
            if (x[i]==0||x[i]==1)
            {}
            else
            {countFalse=countFalse+i;}
        }
        if(countFalse.length()>0)
        {isBinary = false;}
        else
        {isBinary = true;}

        return isBinary;
    }

    /**
     * the method use to convert char array to integer array
     * @param c is a char array
     * @return integer array
     */
    public static int[] charToInt(char[] c){
        int[] in = new int[c.length];
        for(int i=0;i<c.length;i++){
            in[i] = Integer.parseInt(String.valueOf(c[i]));
        }
        return in;
    }

    /**
     * this method use to convert String to char array
     * @param s is String
     * @return char array
     */
    public static char[] breakString(String s){
        char[] ch = new char[s.length()];
        for(int i=0;i<s.length();i++){
            ch[i] = s.charAt(i);
        }
        return ch;
    }

    public static String IntToString(int x){

        return String.valueOf(x);
    }

    public static int StringToInt(String x){

        return Integer.parseInt(x);
    }

    public static String ruotae(String s){
        String ruot="";
        for (int i=s.length()-1;i>=0;i--){
            ruot += s.charAt(i);
        }
        return ruot;
    }


}

